using CarConnect.Model;
using CarConnect.Repository;
namespace CarConncetUnitTets.Tests
{
    
    public class Tests
    {
        

        [Test]
        //Test getting a list of available vehicles.

        public void TestToGetAvailableVehicles()
        {
            VehicleRepository vehicleRepository = new VehicleRepository();
            var allavialablevehicles = vehicleRepository.GetAvailableVehicles();
            Assert.That(3,Is.EqualTo(allavialablevehicles.Count));
        }
        //Test getting a list of all vehicles.
        [Test]
        public void TestToListAllVehicles()
        {
            VehicleRepository vehicleRepository = new VehicleRepository();
            var allavialablevehicles = vehicleRepository.GetAllVehicles();
            Assert.That(5, Is.EqualTo(allavialablevehicles.Count));
        }
        [Test]
        //Test adding a new vehicle
        public void TestToAddVehicle()
        {
            VehicleRepository vehicleRepository=new VehicleRepository();
            int addvehiclestatus = vehicleRepository.AddVehicle(new Vehicle
            {
                Model = "Corolla",
                Make="Toyota",
                Year=DateTime.Now,
                Color="Blue",
                RegistrationNumber="AP0256",
                Availability=0,
                DailyRate=3000.99

            });
            
            Assert.That(1, Is.EqualTo(addvehiclestatus));
        }
        [Test]
        //Test updating vehicle details. 

        public void TestToUpdateVehicle()
        {
            VehicleRepository vehicleRepository = new VehicleRepository();
            int updatestatus = vehicleRepository.UpdateVehicle(new Vehicle
            {
                VehicleID = 1,
                Model = "Corolla",
                Make = "Toyota",
                Year = DateTime.Now,
                Color = "Red",
                RegistrationNumber = "AP03142",
                Availability = 1,
                DailyRate = 5000.99

            });
            Assert.That(1, Is.EqualTo(updatestatus));
        }
        [Test]
        //Test updating customer information.
        public void TestToUpdateCustomer()
        {
            CustomerRepository customerRepository = new CustomerRepository();
            int updatestatus = customerRepository.UpdateCustomer(new Customer
            {
                CustomerID = 1,
                FirstName="Sai",
                LastName="Ganesh",
                Email="Sai@gmail.com",
                PhoneNumber="1234567890",
                Address="1-44-Tiruapthi",
                Username="Sai1234",
                Password="123456",
                RegistrationDate=DateTime.Now

            });
            Assert.That(1, Is.EqualTo(updatestatus));
        }
        [Test]
        //Test customer authentication with invalid credentials.
        public void TestToCustomerAuthetication()
        {
            AuthenticationRepository authenticationRepository = new AuthenticationRepository();
            bool result = authenticationRepository.AuthenticateCustomer("sunil123", "Sunil@123");

            Assert.That(false,Is.EqualTo(result));
        }
        


    }
}